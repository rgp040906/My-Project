import axios from 'axios'
import { useAuthStore } from '@/store/authStore'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8080'

export const apiClient = axios.create({
  baseURL: `${API_URL}/api/v1`,
  headers: { 'Content-Type': 'application/json' },
  timeout: 30000,
})

// ─── Request Interceptor: Attach JWT ─────────────────────────────────────────
apiClient.interceptors.request.use((config) => {
  const token = useAuthStore.getState().accessToken
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// ─── Response Interceptor: Handle 401 + Token Refresh ────────────────────────
apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true
      const { refreshToken, updateTokens, clearAuth } = useAuthStore.getState()
      if (refreshToken) {
        try {
          const res = await axios.post(`${API_URL}/api/v1/auth/refresh`, { refreshToken })
          const { accessToken, refreshToken: newRefresh } = res.data.data
          updateTokens(accessToken, newRefresh)
          original.headers.Authorization = `Bearer ${accessToken}`
          return apiClient(original)
        } catch {
          clearAuth()
          window.location.href = '/login'
        }
      } else {
        clearAuth()
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

// ─── Auth API ─────────────────────────────────────────────────────────────────
export const authApi = {
  login: (email: string, password: string) =>
    apiClient.post('/auth/login', { email, password }),
  register: (data: { name: string; email: string; password: string; phoneNumber?: string }) =>
    apiClient.post('/auth/register', data),
  logout: (refreshToken: string) =>
    apiClient.post('/auth/logout', { refreshToken }),
}

// ─── Complaints API ───────────────────────────────────────────────────────────
export const complaintsApi = {
  create: (data: FormData) =>
    apiClient.post('/complaints', data, { headers: { 'Content-Type': 'multipart/form-data' } }),
  getMy: (page = 0, size = 10) =>
    apiClient.get(`/complaints/my?page=${page}&size=${size}`),
  getAll: (page = 0, size = 20) =>
    apiClient.get(`/complaints?page=${page}&size=${size}`),
  getById: (id: string) =>
    apiClient.get(`/complaints/${id}`),
  getGeo: () =>
    apiClient.get('/complaints/geo'),
  updateStatus: (id: string, newStatus: string, remarks?: string) =>
    apiClient.patch(`/complaints/${id}/status`, { newStatus, remarks }),
  rate: (id: string, stars: number, feedback?: string) =>
    apiClient.post(`/complaints/${id}/rate`, { stars, feedback }),
}

// ─── Analytics API ────────────────────────────────────────────────────────────
export const analyticsApi = {
  getDashboard: () => apiClient.get('/analytics/dashboard'),
}

// ─── Notifications API ────────────────────────────────────────────────────────
export const notificationsApi = {
  getAll: (page = 0, size = 20) =>
    apiClient.get(`/notifications?page=${page}&size=${size}`),
  markAllRead: () =>
    apiClient.put('/notifications/read-all'),
}

// ─── Departments API ──────────────────────────────────────────────────────────
export const departmentsApi = {
  getAll: () => apiClient.get('/departments'),
  create: (data: any) => apiClient.post('/departments', data),
}

// ─── Users API ────────────────────────────────────────────────────────────────
export const usersApi = {
  getAll: (page = 0, size = 20) => apiClient.get(`/users?page=${page}&size=${size}`),
  getProfile: () => apiClient.get('/users/me'),
}

// ─── AI API ───────────────────────────────────────────────────────────────────
export const aiApi = {
  previewAnalysis: (title: string, description: string, address?: string) =>
    apiClient.post('/ai/preview', { title, description, address }),
  chat: (message: string) =>
    apiClient.post('/ai/chat', { message }),
}
