import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { AuthResponse, Role } from '@/types'

interface AuthState {
  accessToken: string | null
  refreshToken: string | null
  userId: string | null
  name: string | null
  email: string | null
  role: Role | null
  isAuthenticated: boolean

  setAuth: (auth: AuthResponse) => void
  clearAuth: () => void
  updateTokens: (accessToken: string, refreshToken: string) => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      accessToken: null,
      refreshToken: null,
      userId: null,
      name: null,
      email: null,
      role: null,
      isAuthenticated: false,

      setAuth: (auth) => set({
        accessToken: auth.accessToken,
        refreshToken: auth.refreshToken,
        userId: auth.userId,
        name: auth.name,
        email: auth.email,
        role: auth.role,
        isAuthenticated: true,
      }),

      clearAuth: () => set({
        accessToken: null,
        refreshToken: null,
        userId: null,
        name: null,
        email: null,
        role: null,
        isAuthenticated: false,
      }),

      updateTokens: (accessToken, refreshToken) => set({ accessToken, refreshToken }),
    }),
    {
      name: 'civicsphere-auth',
      partialize: (state) => ({
        accessToken: state.accessToken,
        refreshToken: state.refreshToken,
        userId: state.userId,
        name: state.name,
        email: state.email,
        role: state.role,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
)
