// ─── TypeScript Types for CivicSphere AI ─────────────────────────────────────

export type Role = 'CITIZEN' | 'STAFF' | 'SUPERVISOR' | 'ADMIN' | 'SUPER_ADMIN'

export type ComplaintStatus =
  | 'SUBMITTED' | 'VERIFIED' | 'ASSIGNED' | 'IN_PROGRESS'
  | 'RESOLVED' | 'CLOSED' | 'REJECTED' | 'SLA_BREACHED'

export type ComplaintCategory =
  | 'ROAD' | 'WATER' | 'POWER' | 'SANITATION' | 'PUBLIC_SAFETY'
  | 'PARKS' | 'TRANSPORTATION' | 'HEALTH' | 'EDUCATION' | 'OTHER'

export type Priority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'

export type NotificationType =
  | 'COMPLAINT_SUBMITTED' | 'COMPLAINT_ASSIGNED' | 'STATUS_UPDATED'
  | 'COMPLAINT_RESOLVED' | 'SLA_BREACHED' | 'COMPLAINT_ESCALATED' | 'SYSTEM'

// ─── Auth ─────────────────────────────────────────────────────────────────────
export interface AuthResponse {
  accessToken: string
  refreshToken: string
  tokenType: string
  expiresIn: number
  userId: string
  name: string
  email: string
  role: Role
}

export interface LoginRequest {
  email: string
  password: string
}

export interface RegisterRequest {
  name: string
  email: string
  password: string
  phoneNumber?: string
}

// ─── User ─────────────────────────────────────────────────────────────────────
export interface User {
  id: string
  name: string
  email: string
  role: Role
  department?: Department
  phoneNumber?: string
  profileImageUrl?: string
  active: boolean
  emailVerified: boolean
  createdAt: string
}

// ─── Department ───────────────────────────────────────────────────────────────
export interface Department {
  id: string
  name: string
  code: string
  description?: string
  headName?: string
  contactEmail?: string
  primaryCategory?: ComplaintCategory
  active: boolean
}

// ─── Complaint ────────────────────────────────────────────────────────────────
export interface CitizenSummary { id: string; name: string; email: string }
export interface DepartmentSummary { id: string; name: string; code: string }

export interface StatusHistoryEntry {
  oldStatus: ComplaintStatus | null
  newStatus: ComplaintStatus
  remarks?: string
  updatedBy: string
  timestamp: string
}

export interface Complaint {
  id: string
  title: string
  description: string
  category: ComplaintCategory
  priority: Priority
  status: ComplaintStatus
  citizen: CitizenSummary
  department?: DepartmentSummary
  latitude?: number
  longitude?: number
  address?: string
  impactScore?: number
  slaDeadline?: string
  resolvedAt?: string
  citizenRating?: number
  citizenFeedback?: string
  imageUrls: string[]
  statusHistory: StatusHistoryEntry[]
  createdAt: string
  updatedAt: string
}

export interface CreateComplaintRequest {
  title: string
  description: string
  category: ComplaintCategory
  priority?: Priority
  latitude?: number
  longitude?: number
  address?: string
}

// ─── Analytics ────────────────────────────────────────────────────────────────
export interface CategoryStat { category: string; count: number }
export interface DeptPerformanceStat { department: string; total: number; resolved: number; resolutionRate: number }
export interface MonthlyTrendStat { month: string; count: number }

export interface DashboardStats {
  totalComplaints: number
  submittedCount: number
  inProgressCount: number
  resolvedCount: number
  slaBreachedCount: number
  resolutionRate: number
  avgResolutionHours?: number
  totalCitizens: number
  totalStaff: number
  byCategory: CategoryStat[]
  departmentPerformance: DeptPerformanceStat[]
  monthlyTrend: MonthlyTrendStat[]
}

// ─── Notification ─────────────────────────────────────────────────────────────
export interface Notification {
  id: string
  title: string
  message: string
  type: NotificationType
  read: boolean
  referenceId?: string
  createdAt: string
}

// ─── API Response ─────────────────────────────────────────────────────────────
export interface ApiResponse<T> {
  success: boolean
  message?: string
  data?: T
  error?: string
  timestamp: string
}

export interface PageResponse<T> {
  content: T[]
  page: number
  size: number
  totalElements: number
  totalPages: number
  last: boolean
}
