package com.civicsphere.common.enums;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
