package com.civicsphere.ai.dto;

import com.civicsphere.common.enums.ComplaintCategory;
import com.civicsphere.common.enums.Priority;
import lombok.Builder;
import lombok.Data;

import java.util.UUID;

@Data
@Builder
public class AiAnalysisResult {
    private ComplaintCategory predictedCategory;
    private Priority predictedPriority;
    private String predictedDepartment;
    private Double confidence;
    private String sentiment;
    private Integer impactScore;
    private String reasoning;
    private UUID duplicateOfId;
    private Double similarityScore;
}
