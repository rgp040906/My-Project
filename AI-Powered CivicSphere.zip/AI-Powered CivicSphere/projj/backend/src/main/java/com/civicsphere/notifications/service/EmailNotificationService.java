package com.civicsphere.notifications.service;

import com.civicsphere.complaints.entity.Complaint;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import jakarta.mail.internet.MimeMessage;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailNotificationService {

    private final JavaMailSender mailSender;
    private final TemplateEngine templateEngine;

    @Async
    public void sendComplaintSubmittedEmail(String toEmail, String name, Complaint complaint) {
        try {
            Context ctx = new Context();
            ctx.setVariable("name", name);
            ctx.setVariable("complaintTitle", complaint.getTitle());
            ctx.setVariable("complaintId", complaint.getId().toString().substring(0, 8).toUpperCase());
            ctx.setVariable("category", complaint.getCategory().name());
            ctx.setVariable("priority", complaint.getPriority().name());
            ctx.setVariable("slaDeadline", complaint.getSlaDeadline());

            String html = templateEngine.process("email/complaint-submitted", ctx);
            sendHtml(toEmail, "CivicSphere — Complaint Received ✓", html);
        } catch (Exception e) {
            log.warn("Failed to send complaint submitted email to {}: {}", toEmail, e.getMessage());
        }
    }

    @Async
    public void sendAssignmentEmail(String toEmail, String name, Complaint complaint) {
        try {
            Context ctx = new Context();
            ctx.setVariable("name", name);
            ctx.setVariable("complaintTitle", complaint.getTitle());
            ctx.setVariable("priority", complaint.getPriority().name());
            ctx.setVariable("category", complaint.getCategory().name());
            ctx.setVariable("slaDeadline", complaint.getSlaDeadline());

            String html = templateEngine.process("email/staff-assigned", ctx);
            sendHtml(toEmail, "CivicSphere — New Complaint Assigned to You", html);
        } catch (Exception e) {
            log.warn("Failed to send assignment email to {}: {}", toEmail, e.getMessage());
        }
    }

    private void sendHtml(String to, String subject, String html) throws Exception {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
        helper.setTo(to);
        helper.setSubject(subject);
        helper.setFrom("noreply@civicsphere.io");
        helper.setText(html, true);
        mailSender.send(message);
        log.debug("Email sent to {}: {}", to, subject);
    }
}
