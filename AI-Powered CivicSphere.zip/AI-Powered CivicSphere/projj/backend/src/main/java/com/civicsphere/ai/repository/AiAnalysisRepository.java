package com.civicsphere.ai.repository;

import com.civicsphere.ai.entity.AiAnalysis;
import com.civicsphere.complaints.entity.Complaint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface AiAnalysisRepository extends JpaRepository<AiAnalysis, UUID> {
    Optional<AiAnalysis> findByComplaint(Complaint complaint);
}
