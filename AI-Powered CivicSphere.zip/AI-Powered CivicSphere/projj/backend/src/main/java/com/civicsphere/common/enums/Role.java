package com.civicsphere.common.enums;

public enum Role {
    CITIZEN,
    STAFF,
    SUPERVISOR,
    ADMIN,
    SUPER_ADMIN
}
