package com.civicsphere.notifications.service;

import com.civicsphere.common.enums.ComplaintStatus;
import com.civicsphere.common.enums.NotificationType;
import com.civicsphere.complaints.entity.Complaint;
import com.civicsphere.notifications.entity.Notification;
import com.civicsphere.notifications.repository.NotificationRepository;
import com.civicsphere.users.entity.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final SimpMessagingTemplate messagingTemplate;
    private final EmailNotificationService emailService;

    @Async
    @Transactional
    public void notifyCitizenComplaintSubmitted(User citizen, Complaint complaint) {
        String title = "Complaint Submitted ✓";
        String message = String.format("Your complaint '%s' has been received and is being processed. Reference: #%s",
                complaint.getTitle(), complaint.getId().toString().substring(0, 8).toUpperCase());

        Notification notification = saveNotification(citizen, title, message,
                NotificationType.COMPLAINT_SUBMITTED, complaint.getId());

        pushToWebSocket(citizen.getId().toString(), notification);
        emailService.sendComplaintSubmittedEmail(citizen.getEmail(), citizen.getName(), complaint);
    }

    @Async
    @Transactional
    public void notifyStaffAssigned(User staff, Complaint complaint) {
        String title = "New Complaint Assigned";
        String message = String.format("A new %s complaint has been assigned to you: '%s' [Priority: %s]",
                complaint.getCategory().name(), complaint.getTitle(), complaint.getPriority().name());

        Notification notification = saveNotification(staff, title, message,
                NotificationType.COMPLAINT_ASSIGNED, complaint.getId());

        pushToWebSocket(staff.getId().toString(), notification);
        emailService.sendAssignmentEmail(staff.getEmail(), staff.getName(), complaint);
    }

    @Async
    @Transactional
    public void notifyStatusChanged(Complaint complaint, ComplaintStatus oldStatus, ComplaintStatus newStatus) {
        User citizen = complaint.getCitizen();
        String title = "Complaint Status Updated";
        String message = String.format("Your complaint '%s' status changed from %s to %s",
                complaint.getTitle(), oldStatus.name(), newStatus.name());

        if (newStatus == ComplaintStatus.RESOLVED) {
            message += ". Please rate our service!";
        }

        Notification notification = saveNotification(citizen, title, message,
                NotificationType.STATUS_UPDATED, complaint.getId());

        pushToWebSocket(citizen.getId().toString(), notification);

        // Also broadcast to complaint topic for real-time UI update
        messagingTemplate.convertAndSend(
                "/topic/complaints/" + complaint.getId(),
                Map.of("status", newStatus.name(), "complaintId", complaint.getId())
        );
    }

    @Async
    @Transactional
    public void notifySlaBreached(Complaint complaint) {
        // Notify citizen
        String citizenMsg = "Your complaint '" + complaint.getTitle() + "' SLA has been breached. It has been escalated.";
        Notification citizenNotif = saveNotification(complaint.getCitizen(), "SLA Breached - Escalated",
                citizenMsg, NotificationType.SLA_BREACHED, complaint.getId());
        pushToWebSocket(complaint.getCitizen().getId().toString(), citizenNotif);

        // Broadcast to admin SLA topic
        messagingTemplate.convertAndSend("/topic/admin/sla",
                Map.of("complaintId", complaint.getId(), "title", complaint.getTitle(),
                       "category", complaint.getCategory().name(), "priority", complaint.getPriority().name()));

        log.warn("SLA BREACH: Complaint {} - {}", complaint.getId(), complaint.getTitle());
    }

    private Notification saveNotification(User user, String title, String message,
                                           NotificationType type, java.util.UUID referenceId) {
        Notification notification = Notification.builder()
                .user(user)
                .title(title)
                .message(message)
                .type(type)
                .referenceId(referenceId)
                .referenceType("COMPLAINT")
                .read(false)
                .build();
        return notificationRepository.save(notification);
    }

    private void pushToWebSocket(String userId, Notification notification) {
        messagingTemplate.convertAndSendToUser(userId, "/queue/notifications",
                Map.of("id", notification.getId(), "title", notification.getTitle(),
                       "message", notification.getMessage(), "type", notification.getType()));
    }
}
