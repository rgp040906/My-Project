package com.civicsphere.complaints.dto;

import com.civicsphere.common.enums.ComplaintStatus;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UpdateStatusRequest {

    @NotNull(message = "New status is required")
    private ComplaintStatus newStatus;

    private String remarks;
}
