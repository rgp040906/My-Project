package com.civicsphere.ai.entity;

import com.civicsphere.common.enums.ComplaintCategory;
import com.civicsphere.common.enums.Priority;
import com.civicsphere.complaints.entity.Complaint;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "ai_analyses")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AiAnalysis {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "complaint_id", nullable = false, unique = true)
    private Complaint complaint;

    @Enumerated(EnumType.STRING)
    @Column(name = "predicted_category")
    private ComplaintCategory predictedCategory;

    @Enumerated(EnumType.STRING)
    @Column(name = "predicted_priority")
    private Priority predictedPriority;

    @Column(name = "confidence")
    private Double confidence;

    @Column(name = "sentiment")
    private String sentiment;

    @Column(name = "impact_score")
    private Integer impactScore;

    @Column(name = "predicted_department")
    private String predictedDepartment;

    @Column(name = "duplicate_of_id")
    private UUID duplicateOfId;

    @Column(name = "similarity_score")
    private Double similarityScore;

    @Column(name = "reasoning", columnDefinition = "TEXT")
    private String reasoning;

    @CreationTimestamp
    @Column(name = "analyzed_at")
    private LocalDateTime analyzedAt;
}
