package com.civicsphere.departments.dto;

import com.civicsphere.common.enums.ComplaintCategory;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CreateDepartmentRequest {
    @NotBlank(message = "Department name is required")
    private String name;

    @NotBlank(message = "Department code is required")
    private String code;

    private String description;
    private String headName;
    private String contactEmail;
    private String contactPhone;

    @NotNull(message = "Primary category is required")
    private ComplaintCategory primaryCategory;
}
