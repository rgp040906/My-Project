package com.civicsphere.departments.dto;

import com.civicsphere.common.enums.ComplaintCategory;
import lombok.Builder;
import lombok.Data;

import java.util.UUID;

@Data
@Builder
public class DepartmentResponse {
    private UUID id;
    private String name;
    private String code;
    private String description;
    private String headName;
    private String contactEmail;
    private String contactPhone;
    private ComplaintCategory primaryCategory;
    private boolean active;
}
