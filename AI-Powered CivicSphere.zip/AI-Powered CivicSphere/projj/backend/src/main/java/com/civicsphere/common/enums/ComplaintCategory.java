package com.civicsphere.common.enums;

public enum ComplaintCategory {
    ROAD,
    WATER,
    POWER,
    SANITATION,
    PUBLIC_SAFETY,
    PARKS,
    TRANSPORTATION,
    HEALTH,
    EDUCATION,
    OTHER
}
