package com.civicsphere.complaints.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Set;
import java.util.UUID;

@Service
@Slf4j
public class FileStorageService {

    private static final Set<String> ALLOWED_TYPES = Set.of(
            "image/jpeg", "image/png", "image/webp", "application/pdf"
    );
    private static final long MAX_SIZE = 5 * 1024 * 1024; // 5MB

    @Value("${app.storage.type}")
    private String storageType;

    @Value("${app.storage.local-path}")
    private String localPath;

    @Value("${app.frontend-url}")
    private String frontendUrl;

    public String store(MultipartFile file, String folder) {
        validate(file);
        if ("s3".equalsIgnoreCase(storageType)) {
            return storeToS3(file, folder);
        }
        return storeLocally(file, folder);
    }

    private void validate(MultipartFile file) {
        if (file.isEmpty()) throw new IllegalArgumentException("File is empty");
        if (file.getSize() > MAX_SIZE) throw new IllegalArgumentException("File exceeds 5MB limit");
        if (!ALLOWED_TYPES.contains(file.getContentType())) {
            throw new IllegalArgumentException("File type not allowed: " + file.getContentType());
        }
    }

    private String storeLocally(MultipartFile file, String folder) {
        try {
            String ext = getExtension(file.getOriginalFilename());
            String filename = UUID.randomUUID() + ext;
            Path dir = Paths.get(localPath, folder);
            Files.createDirectories(dir);
            Path target = dir.resolve(filename);
            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
            String relativePath = "/" + localPath + "/" + folder + "/" + filename;
            log.info("Stored file locally: {}", relativePath);
            return relativePath;
        } catch (IOException e) {
            throw new RuntimeException("Failed to store file: " + e.getMessage(), e);
        }
    }

    private String storeToS3(MultipartFile file, String folder) {
        // AWS S3 implementation — inject S3Client via constructor when storage.type=s3
        throw new UnsupportedOperationException("S3 storage not configured. Set STORAGE_TYPE=local or configure AWS credentials.");
    }

    private String getExtension(String filename) {
        if (filename == null || !filename.contains(".")) return "";
        return filename.substring(filename.lastIndexOf("."));
    }
}
