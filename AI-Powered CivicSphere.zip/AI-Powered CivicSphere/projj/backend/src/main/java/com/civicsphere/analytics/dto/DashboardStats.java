package com.civicsphere.analytics.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
@Builder
public class DashboardStats {
    private long totalComplaints;
    private long submittedCount;
    private long inProgressCount;
    private long resolvedCount;
    private long slaBreachedCount;
    private double resolutionRate;
    private Double avgResolutionHours;
    private long totalCitizens;
    private long totalStaff;
    private List<CategoryStat> byCategory;
    private List<DeptPerformanceStat> departmentPerformance;
    private List<MonthlyTrendStat> monthlyTrend;

    @Data
    @Builder
    public static class CategoryStat {
        private String category;
        private long count;
    }

    @Data
    @Builder
    public static class DeptPerformanceStat {
        private String department;
        private long total;
        private long resolved;
        private double resolutionRate;
    }

    @Data
    @Builder
    public static class MonthlyTrendStat {
        private String month;
        private long count;
    }
}
