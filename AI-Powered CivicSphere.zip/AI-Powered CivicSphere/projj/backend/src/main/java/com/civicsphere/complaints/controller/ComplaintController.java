package com.civicsphere.complaints.controller;

import com.civicsphere.common.dto.ApiResponse;
import com.civicsphere.common.dto.PageResponse;
import com.civicsphere.complaints.dto.*;
import com.civicsphere.complaints.service.ComplaintService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/complaints")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Complaints", description = "Complaint lifecycle management")
public class ComplaintController {

    private final ComplaintService complaintService;

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Submit a new complaint (Citizen)")
    @PreAuthorize("hasRole('CITIZEN')")
    public ResponseEntity<ApiResponse<ComplaintResponse>> create(
            @Valid @RequestPart("data") CreateComplaintRequest request,
            @RequestPart(value = "images", required = false) List<MultipartFile> images) {
        ComplaintResponse response = complaintService.createComplaint(request, images);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("Complaint submitted successfully", response));
    }

    @GetMapping("/my")
    @Operation(summary = "Get my complaints (Citizen)")
    @PreAuthorize("hasRole('CITIZEN')")
    public ResponseEntity<ApiResponse<PageResponse<ComplaintResponse>>> getMyComplaints(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(ApiResponse.success(complaintService.getMyCcomplaints(page, size)));
    }

    @GetMapping("/assigned")
    @Operation(summary = "Get my assigned complaints (Staff/Supervisor)")
    @PreAuthorize("hasAnyRole('STAFF', 'SUPERVISOR')")
    public ResponseEntity<ApiResponse<PageResponse<ComplaintResponse>>> getAssignedComplaints(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(ApiResponse.success(complaintService.getAssignedComplaints(page, size)));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get complaint by ID")
    public ResponseEntity<ApiResponse<ComplaintResponse>> getById(@PathVariable UUID id) {
        return ResponseEntity.ok(ApiResponse.success(complaintService.getComplaintById(id)));
    }

    @GetMapping
    @Operation(summary = "Get all complaints (Admin/Supervisor)")
    @PreAuthorize("hasAnyRole('ADMIN', 'SUPER_ADMIN', 'SUPERVISOR')")
    public ResponseEntity<ApiResponse<PageResponse<ComplaintResponse>>> getAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(complaintService.getAllComplaints(page, size)));
    }

    @GetMapping("/geo")
    @Operation(summary = "Get all complaints with geo-coordinates for map")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> getGeoComplaints() {
        return ResponseEntity.ok(ApiResponse.success(complaintService.getGeoComplaints()));
    }

    @PatchMapping("/{id}/status")
    @Operation(summary = "Update complaint status (Staff/Supervisor/Admin)")
    @PreAuthorize("hasAnyRole('STAFF', 'SUPERVISOR', 'ADMIN', 'SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<ComplaintResponse>> updateStatus(
            @PathVariable UUID id,
            @Valid @RequestBody UpdateStatusRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Status updated", complaintService.updateStatus(id, request)));
    }

    @PostMapping("/{id}/rate")
    @Operation(summary = "Rate resolved complaint (Citizen)")
    @PreAuthorize("hasRole('CITIZEN')")
    public ResponseEntity<ApiResponse<ComplaintResponse>> rate(
            @PathVariable UUID id,
            @Valid @RequestBody RatingRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Thank you for your feedback!", complaintService.rateComplaint(id, request)));
    }
}
