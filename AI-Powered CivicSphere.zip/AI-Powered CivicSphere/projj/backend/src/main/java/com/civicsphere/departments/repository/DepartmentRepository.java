package com.civicsphere.departments.repository;

import com.civicsphere.common.enums.ComplaintCategory;
import com.civicsphere.departments.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, UUID> {
    Optional<Department> findByPrimaryCategory(ComplaintCategory category);
    Optional<Department> findByCode(String code);
    boolean existsByCode(String code);
}
