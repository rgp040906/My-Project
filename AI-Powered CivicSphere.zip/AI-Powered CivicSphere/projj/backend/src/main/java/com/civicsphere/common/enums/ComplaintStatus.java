package com.civicsphere.common.enums;

public enum ComplaintStatus {
    SUBMITTED,
    VERIFIED,
    ASSIGNED,
    IN_PROGRESS,
    RESOLVED,
    CLOSED,
    REJECTED,
    SLA_BREACHED
}
