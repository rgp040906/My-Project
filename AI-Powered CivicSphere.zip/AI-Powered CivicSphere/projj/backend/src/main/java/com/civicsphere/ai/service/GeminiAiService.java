package com.civicsphere.ai.service;

import com.civicsphere.ai.dto.AiAnalysisResult;
import com.civicsphere.common.enums.ComplaintCategory;
import com.civicsphere.common.enums.Priority;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Map;
import java.util.Random;

@Service
@RequiredArgsConstructor
@Slf4j
public class GeminiAiService {

    private final WebClient.Builder webClientBuilder;
    private final ObjectMapper objectMapper;

    @Value("${app.ai.gemini.api-key}")
    private String apiKey;

    @Value("${app.ai.gemini.base-url}")
    private String baseUrl;

    @Value("${app.ai.gemini.model}")
    private String model;

    @Value("${app.ai.gemini.mock-enabled}")
    private boolean mockEnabled;

    public AiAnalysisResult analyzeComplaint(String title, String description, String address) {
        if (mockEnabled) {
            return generateMockAnalysis(title, description);
        }
        return callGeminiApi(title, description, address);
    }

    private AiAnalysisResult callGeminiApi(String title, String description, String address) {
        String prompt = buildAnalysisPrompt(title, description, address);

        try {
            String url = baseUrl + "/" + model + ":generateContent?key=" + apiKey;

            Map<String, Object> requestBody = Map.of(
                "contents", new Object[]{
                    Map.of("parts", new Object[]{
                        Map.of("text", prompt)
                    })
                },
                "generationConfig", Map.of(
                    "temperature", 0.2,
                    "responseMimeType", "application/json"
                )
            );

            String responseStr = webClientBuilder.build()
                    .post()
                    .uri(url)
                    .header("Content-Type", "application/json")
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            return parseGeminiResponse(responseStr);

        } catch (Exception e) {
            log.error("Gemini API call failed, using mock: {}", e.getMessage());
            return generateMockAnalysis(title, description);
        }
    }

    private String buildAnalysisPrompt(String title, String description, String address) {
        return """
            You are a civic complaint analysis AI for CivicSphere, a smart city management platform.
            
            Analyze the following complaint and return a JSON object with these exact fields:
            {
              "predictedCategory": one of [ROAD, WATER, POWER, SANITATION, PUBLIC_SAFETY, PARKS, TRANSPORTATION, HEALTH, EDUCATION, OTHER],
              "predictedPriority": one of [LOW, MEDIUM, HIGH, CRITICAL],
              "predictedDepartment": string (department name),
              "confidence": number between 0 and 1,
              "sentiment": one of [NORMAL, URGENT, CRITICAL],
              "impactScore": integer between 1 and 100,
              "reasoning": brief explanation string
            }
            
            Complaint Title: %s
            Description: %s
            Location: %s
            
            Return only valid JSON, no markdown.
            """.formatted(title, description, address != null ? address : "Not specified");
    }

    private AiAnalysisResult parseGeminiResponse(String responseStr) throws Exception {
        JsonNode root = objectMapper.readTree(responseStr);
        String text = root
                .path("candidates").get(0)
                .path("content").path("parts").get(0)
                .path("text").asText();

        JsonNode result = objectMapper.readTree(text);

        return AiAnalysisResult.builder()
                .predictedCategory(ComplaintCategory.valueOf(result.path("predictedCategory").asText("OTHER")))
                .predictedPriority(Priority.valueOf(result.path("predictedPriority").asText("MEDIUM")))
                .predictedDepartment(result.path("predictedDepartment").asText())
                .confidence(result.path("confidence").asDouble(0.8))
                .sentiment(result.path("sentiment").asText("NORMAL"))
                .impactScore(result.path("impactScore").asInt(50))
                .reasoning(result.path("reasoning").asText())
                .build();
    }

    private AiAnalysisResult generateMockAnalysis(String title, String description) {
        String lowerTitle = (title + " " + description).toLowerCase();
        ComplaintCategory category = detectCategoryFromText(lowerTitle);
        Priority priority = detectPriorityFromText(lowerTitle);
        String sentiment = detectSentimentFromText(lowerTitle);

        Random rand = new Random(title.hashCode());
        int impactScore = 40 + rand.nextInt(55);
        double confidence = 0.75 + (rand.nextDouble() * 0.20);

        String deptName = switch (category) {
            case ROAD -> "Roads & Infrastructure Dept";
            case WATER -> "Water Supply Board";
            case POWER -> "Electricity Board";
            case SANITATION -> "Sanitation & Waste Mgmt";
            case PUBLIC_SAFETY -> "Public Safety Dept";
            case PARKS -> "Parks & Recreation Dept";
            case TRANSPORTATION -> "City Transport Authority";
            case HEALTH -> "Health Department";
            case EDUCATION -> "Education Department";
            default -> "General Administration";
        };

        log.info("[MOCK AI] Category={} Priority={} Impact={} Confidence={}",
                category, priority, impactScore, String.format("%.2f", confidence));

        return AiAnalysisResult.builder()
                .predictedCategory(category)
                .predictedPriority(priority)
                .predictedDepartment(deptName)
                .confidence(confidence)
                .sentiment(sentiment)
                .impactScore(impactScore)
                .reasoning("AI classification based on complaint keywords and context analysis.")
                .build();
    }

    private ComplaintCategory detectCategoryFromText(String text) {
        if (text.contains("road") || text.contains("pothole") || text.contains("street") || text.contains("pavement")) return ComplaintCategory.ROAD;
        if (text.contains("water") || text.contains("pipe") || text.contains("leak") || text.contains("flood")) return ComplaintCategory.WATER;
        if (text.contains("power") || text.contains("electric") || text.contains("light") || text.contains("outage")) return ComplaintCategory.POWER;
        if (text.contains("garbage") || text.contains("waste") || text.contains("sanit") || text.contains("drain")) return ComplaintCategory.SANITATION;
        if (text.contains("safety") || text.contains("crime") || text.contains("police") || text.contains("theft")) return ComplaintCategory.PUBLIC_SAFETY;
        if (text.contains("park") || text.contains("garden") || text.contains("tree")) return ComplaintCategory.PARKS;
        if (text.contains("bus") || text.contains("transport") || text.contains("traffic")) return ComplaintCategory.TRANSPORTATION;
        if (text.contains("hospital") || text.contains("health") || text.contains("clinic")) return ComplaintCategory.HEALTH;
        return ComplaintCategory.OTHER;
    }

    private Priority detectPriorityFromText(String text) {
        if (text.contains("emergency") || text.contains("danger") || text.contains("critical") || text.contains("urgent")) return Priority.CRITICAL;
        if (text.contains("hospital") || text.contains("school") || text.contains("severe") || text.contains("major")) return Priority.HIGH;
        if (text.contains("minor") || text.contains("small") || text.contains("slight")) return Priority.LOW;
        return Priority.MEDIUM;
    }

    private String detectSentimentFromText(String text) {
        if (text.contains("emergency") || text.contains("danger") || text.contains("critical")) return "CRITICAL";
        if (text.contains("urgent") || text.contains("immediately") || text.contains("asap") || text.contains("serious")) return "URGENT";
        return "NORMAL";
    }

    public String chatWithAssistant(String userMessage) {
        if (mockEnabled) {
            return generateMockChatResponse(userMessage);
        }

        String prompt = """
            You are a helpful civic services assistant for CivicSphere, a smart city management platform.
            Help citizens with questions about their complaints, civic services, and processes.
            Be concise and helpful.
            
            User: %s
            """.formatted(userMessage);

        try {
            String url = baseUrl + "/" + model + ":generateContent?key=" + apiKey;
            Map<String, Object> requestBody = Map.of(
                "contents", new Object[]{ Map.of("parts", new Object[]{ Map.of("text", prompt) }) }
            );

            String responseStr = webClientBuilder.build()
                    .post().uri(url)
                    .header("Content-Type", "application/json")
                    .bodyValue(requestBody)
                    .retrieve().bodyToMono(String.class).block();

            JsonNode root = objectMapper.readTree(responseStr);
            return root.path("candidates").get(0)
                    .path("content").path("parts").get(0)
                    .path("text").asText("I'm here to help! Could you rephrase your question?");

        } catch (Exception e) {
            log.error("Gemini chat API failed: {}", e.getMessage());
            return generateMockChatResponse(userMessage);
        }
    }

    private String generateMockChatResponse(String message) {
        String lowerMsg = message.toLowerCase();
        if (lowerMsg.contains("status") || lowerMsg.contains("complaint")) {
            return "You can track your complaint status in real-time from your citizen dashboard. Go to 'My Complaints' to see the current status and history.";
        }
        if (lowerMsg.contains("delay") || lowerMsg.contains("slow")) {
            return "I understand your frustration. Complaint resolution times vary by category — Water issues are resolved within 24 hours, Road issues within 72 hours. If SLA is breached, the complaint is automatically escalated to a supervisor.";
        }
        if (lowerMsg.contains("electric") || lowerMsg.contains("power")) {
            return "Electricity-related complaints are handled by the Electricity Board department. Power outages are marked HIGH priority and must be resolved within 12 hours.";
        }
        return "Thank you for reaching out! I can help you track complaints, understand resolution timelines, or guide you through filing a new complaint. What do you need help with?";
    }
}
