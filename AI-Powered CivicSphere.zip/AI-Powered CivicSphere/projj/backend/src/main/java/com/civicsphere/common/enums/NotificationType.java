package com.civicsphere.common.enums;

public enum NotificationType {
    COMPLAINT_SUBMITTED,
    COMPLAINT_ASSIGNED,
    STATUS_UPDATED,
    COMPLAINT_RESOLVED,
    SLA_BREACHED,
    COMPLAINT_ESCALATED,
    SYSTEM
}
