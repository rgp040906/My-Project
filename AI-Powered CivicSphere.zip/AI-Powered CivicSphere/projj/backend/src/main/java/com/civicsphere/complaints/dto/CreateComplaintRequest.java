package com.civicsphere.complaints.dto;

import com.civicsphere.common.enums.ComplaintCategory;
import com.civicsphere.common.enums.Priority;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class CreateComplaintRequest {

    @NotBlank(message = "Title is required")
    @Size(min = 10, max = 200, message = "Title must be 10-200 characters")
    private String title;

    @NotBlank(message = "Description is required")
    @Size(min = 20, max = 2000, message = "Description must be 20-2000 characters")
    private String description;

    @NotNull(message = "Category is required")
    private ComplaintCategory category;

    private Priority priority;

    private Double latitude;
    private Double longitude;

    @Size(max = 500, message = "Address max 500 characters")
    private String address;
}
