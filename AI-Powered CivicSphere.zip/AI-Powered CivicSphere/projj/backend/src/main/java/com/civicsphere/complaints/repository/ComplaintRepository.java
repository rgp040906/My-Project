package com.civicsphere.complaints.repository;

import com.civicsphere.common.enums.ComplaintCategory;
import com.civicsphere.common.enums.ComplaintStatus;
import com.civicsphere.common.enums.Priority;
import com.civicsphere.complaints.entity.Complaint;
import com.civicsphere.users.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface ComplaintRepository extends JpaRepository<Complaint, UUID> {

    Page<Complaint> findByCitizen(User citizen, Pageable pageable);

    Page<Complaint> findByStatus(ComplaintStatus status, Pageable pageable);

    Page<Complaint> findByCategoryAndStatus(ComplaintCategory category, ComplaintStatus status, Pageable pageable);

    @Query("SELECT c FROM Complaint c WHERE c.department.id = :deptId ORDER BY c.createdAt DESC")
    Page<Complaint> findByDepartmentId(@Param("deptId") UUID deptId, Pageable pageable);

    @Query("SELECT c FROM Complaint c WHERE c.slaDeadline < :now AND c.status NOT IN ('RESOLVED','CLOSED','REJECTED','SLA_BREACHED')")
    List<Complaint> findSlaBreachedComplaints(@Param("now") LocalDateTime now);

    @Query("SELECT c.category, COUNT(c) FROM Complaint c GROUP BY c.category")
    List<Object[]> countByCategory();

    @Query("SELECT c.status, COUNT(c) FROM Complaint c GROUP BY c.status")
    List<Object[]> countByStatus();

    @Query("SELECT c.department.name, COUNT(c), SUM(CASE WHEN c.status = 'RESOLVED' THEN 1 ELSE 0 END) FROM Complaint c WHERE c.department IS NOT NULL GROUP BY c.department.name")
    List<Object[]> getDepartmentPerformance();

    @Query("SELECT year(c.createdAt), month(c.createdAt), COUNT(c) FROM Complaint c WHERE c.createdAt >= :since GROUP BY year(c.createdAt), month(c.createdAt) ORDER BY year(c.createdAt), month(c.createdAt)")
    List<Object[]> getMonthlyTrend(@Param("since") LocalDateTime since);

    @Query("SELECT c FROM Complaint c WHERE c.latitude IS NOT NULL AND c.longitude IS NOT NULL")
    List<Complaint> findAllWithLocation();

    long countByStatus(ComplaintStatus status);

    @Query("SELECT AVG(TIMESTAMPDIFF(HOUR, c.createdAt, c.resolvedAt)) FROM Complaint c WHERE c.resolvedAt IS NOT NULL")
    Double avgResolutionTimeHours();
}
