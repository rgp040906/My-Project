package com.civicsphere.complaints.dto;

import com.civicsphere.common.enums.ComplaintCategory;
import com.civicsphere.common.enums.ComplaintStatus;
import com.civicsphere.common.enums.Priority;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Data
@Builder
public class ComplaintResponse {
    private UUID id;
    private String title;
    private String description;
    private ComplaintCategory category;
    private Priority priority;
    private ComplaintStatus status;
    private CitizenSummary citizen;
    private DepartmentSummary department;
    private Double latitude;
    private Double longitude;
    private String address;
    private Integer impactScore;
    private LocalDateTime slaDeadline;
    private LocalDateTime resolvedAt;
    private Integer citizenRating;
    private String citizenFeedback;
    private List<String> imageUrls;
    private List<StatusHistoryDto> statusHistory;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @Data
    @Builder
    public static class CitizenSummary {
        private UUID id;
        private String name;
        private String email;
    }

    @Data
    @Builder
    public static class DepartmentSummary {
        private UUID id;
        private String name;
        private String code;
    }

    @Data
    @Builder
    public static class StatusHistoryDto {
        private ComplaintStatus oldStatus;
        private ComplaintStatus newStatus;
        private String remarks;
        private String updatedBy;
        private LocalDateTime timestamp;
    }
}
