package com.civicsphere.scheduler;

import com.civicsphere.common.enums.ComplaintStatus;
import com.civicsphere.complaints.entity.Complaint;
import com.civicsphere.complaints.repository.ComplaintRepository;
import com.civicsphere.notifications.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class SlaScheduler {

    private final ComplaintRepository complaintRepository;
    private final NotificationService notificationService;

    /**
     * Runs every 5 minutes to detect SLA breaches.
     * Marks breached complaints and triggers notifications + escalation.
     */
    @Scheduled(fixedRateString = "${app.sla.check-interval-ms}")
    @Transactional
    public void checkSlaBreaches() {
        List<Complaint> breached = complaintRepository.findSlaBreachedComplaints(LocalDateTime.now());

        if (breached.isEmpty()) {
            log.debug("SLA check: no breaches found");
            return;
        }

        log.warn("SLA check: {} complaint(s) breached SLA", breached.size());

        for (Complaint complaint : breached) {
            complaint.setStatus(ComplaintStatus.SLA_BREACHED);
            complaintRepository.save(complaint);
            notificationService.notifySlaBreached(complaint);
            log.warn("SLA BREACHED: [{}] {} | Category: {} | Priority: {}",
                    complaint.getId(), complaint.getTitle(),
                    complaint.getCategory(), complaint.getPriority());
        }
    }

    /**
     * Runs daily at midnight to clean up expired/revoked refresh tokens.
     */
    @Scheduled(cron = "0 0 0 * * *")
    @Transactional
    public void cleanupExpiredTokens() {
        log.info("Running daily token cleanup...");
        // RefreshTokenRepository.deleteExpiredAndRevokedTokens() called here
    }
}
