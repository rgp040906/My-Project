package com.civicsphere.assignments.service;

import com.civicsphere.assignments.entity.Assignment;
import com.civicsphere.assignments.repository.AssignmentRepository;
import com.civicsphere.common.enums.Role;
import com.civicsphere.complaints.entity.Complaint;
import com.civicsphere.departments.entity.Department;
import com.civicsphere.notifications.service.NotificationService;
import com.civicsphere.users.entity.User;
import com.civicsphere.users.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class AssignmentService {

    private final AssignmentRepository assignmentRepository;
    private final UserRepository userRepository;
    private final NotificationService notificationService;

    /**
     * Auto-assign complaint to the staff member in the department with the fewest active assignments.
     * This implements load-balanced round-robin assignment.
     */
    public Optional<Assignment> autoAssign(Complaint complaint, Department department) {
        List<User> availableStaff = userRepository.findActiveStaffByDepartment(Role.STAFF, department);

        if (availableStaff.isEmpty()) {
            log.warn("No active staff found in department: {}", department.getName());
            return Optional.empty();
        }

        // Pick staff with the lowest active assignment count (load balancing)
        User selectedStaff = availableStaff.stream()
                .min(Comparator.comparingLong(
                        staff -> assignmentRepository.countActiveAssignmentsByStaff(staff)))
                .orElseThrow();

        // Deactivate any previous assignment for this complaint
        assignmentRepository.findByComplaintAndActive(complaint, true)
                .ifPresent(a -> { a.setActive(false); assignmentRepository.save(a); });

        Assignment assignment = Assignment.builder()
                .complaint(complaint)
                .staff(selectedStaff)
                .active(true)
                .notes("Auto-assigned by CivicSphere AI Engine")
                .build();

        assignment = assignmentRepository.save(assignment);

        // Notify assigned staff
        notificationService.notifyStaffAssigned(selectedStaff, complaint);

        log.info("Complaint {} auto-assigned to staff {} ({})",
                complaint.getId(), selectedStaff.getName(), selectedStaff.getEmail());

        return Optional.of(assignment);
    }

    public Assignment manualAssign(UUID complaintId, UUID staffId, User assignedBy) {
        Complaint complaint = new Complaint();
        complaint.setId(complaintId); // detached reference, full entity loaded in controller

        User staff = userRepository.findById(staffId)
                .orElseThrow(() -> new RuntimeException("Staff not found: " + staffId));

        assignmentRepository.findByComplaintAndActive(complaint, true)
                .ifPresent(a -> { a.setActive(false); assignmentRepository.save(a); });

        Assignment assignment = Assignment.builder()
                .complaint(complaint)
                .staff(staff)
                .assignedBy(assignedBy)
                .active(true)
                .build();

        return assignmentRepository.save(assignment);
    }
}
