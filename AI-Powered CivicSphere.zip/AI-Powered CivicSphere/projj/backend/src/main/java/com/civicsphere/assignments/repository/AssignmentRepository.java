package com.civicsphere.assignments.repository;

import com.civicsphere.assignments.entity.Assignment;
import com.civicsphere.complaints.entity.Complaint;
import com.civicsphere.users.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface AssignmentRepository extends JpaRepository<Assignment, UUID> {
    Optional<Assignment> findByComplaintAndActive(Complaint complaint, boolean active);
    List<Assignment> findByStaffAndActive(User staff, boolean active);
    Page<Assignment> findByStaffAndActive(User staff, boolean active, Pageable pageable);

    @Query("SELECT COUNT(a) FROM Assignment a WHERE a.staff = :staff AND a.active = true")
    long countActiveAssignmentsByStaff(@Param("staff") User staff);

    @Query("SELECT a.staff, COUNT(a) FROM Assignment a WHERE a.active = true GROUP BY a.staff ORDER BY COUNT(a) ASC")
    List<Object[]> getStaffWorkloadAsc();
}
