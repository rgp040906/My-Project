package com.civicsphere.analytics.service;

import com.civicsphere.analytics.dto.DashboardStats;
import com.civicsphere.common.enums.ComplaintStatus;
import com.civicsphere.common.enums.Role;
import com.civicsphere.complaints.repository.ComplaintRepository;
import com.civicsphere.users.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional(readOnly = true)
public class AnalyticsService {

    private final ComplaintRepository complaintRepository;
    private final UserRepository userRepository;

    @Cacheable(value = "dashboardStats", key = "'global'")
    public DashboardStats getDashboardStats() {
        long total = complaintRepository.count();
        long submitted = complaintRepository.countByStatus(ComplaintStatus.SUBMITTED);
        long inProgress = complaintRepository.countByStatus(ComplaintStatus.IN_PROGRESS);
        long resolved = complaintRepository.countByStatus(ComplaintStatus.RESOLVED) +
                        complaintRepository.countByStatus(ComplaintStatus.CLOSED);
        long slaBreach = complaintRepository.countByStatus(ComplaintStatus.SLA_BREACHED);
        double resolutionRate = total > 0 ? (double) resolved / total * 100 : 0;
        Double avgHours = complaintRepository.avgResolutionTimeHours();

        // By category
        List<DashboardStats.CategoryStat> categoryStats = complaintRepository.countByCategory().stream()
                .map(row -> DashboardStats.CategoryStat.builder()
                        .category(row[0].toString())
                        .count((Long) row[1])
                        .build())
                .toList();

        // Department performance
        List<DashboardStats.DeptPerformanceStat> deptStats = complaintRepository.getDepartmentPerformance().stream()
                .map(row -> {
                    long deptTotal = (Long) row[1];
                    long deptResolved = row[2] != null ? ((Number) row[2]).longValue() : 0;
                    double rate = deptTotal > 0 ? (double) deptResolved / deptTotal * 100 : 0;
                    return DashboardStats.DeptPerformanceStat.builder()
                            .department(row[0].toString())
                            .total(deptTotal)
                            .resolved(deptResolved)
                            .resolutionRate(Math.round(rate * 10.0) / 10.0)
                            .build();
                })
                .toList();

        // Monthly trend (last 6 months)
        List<DashboardStats.MonthlyTrendStat> trendStats = complaintRepository
                .getMonthlyTrend(LocalDateTime.now().minusMonths(6)).stream()
                .map(row -> {
                    int year = ((Number) row[0]).intValue();
                    int month = ((Number) row[1]).intValue();
                    String monthStr = java.time.Month.of(month).getDisplayName(java.time.format.TextStyle.SHORT, java.util.Locale.US) + " " + year;
                    return DashboardStats.MonthlyTrendStat.builder()
                            .month(monthStr)
                            .count((Long) row[2])
                            .build();
                })
                .toList();

        return DashboardStats.builder()
                .totalComplaints(total)
                .submittedCount(submitted)
                .inProgressCount(inProgress)
                .resolvedCount(resolved)
                .slaBreachedCount(slaBreach)
                .resolutionRate(Math.round(resolutionRate * 10.0) / 10.0)
                .avgResolutionHours(avgHours != null ? Math.round(avgHours * 10.0) / 10.0 : null)
                .totalCitizens(userRepository.countByRole(Role.CITIZEN))
                .totalStaff(userRepository.countByRole(Role.STAFF))
                .byCategory(categoryStats)
                .departmentPerformance(deptStats)
                .monthlyTrend(trendStats)
                .build();
    }
}
