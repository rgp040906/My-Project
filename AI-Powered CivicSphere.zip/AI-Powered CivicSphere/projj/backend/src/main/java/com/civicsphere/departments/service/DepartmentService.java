package com.civicsphere.departments.service;

import com.civicsphere.departments.dto.CreateDepartmentRequest;
import com.civicsphere.departments.dto.DepartmentResponse;
import com.civicsphere.departments.entity.Department;
import com.civicsphere.departments.repository.DepartmentRepository;
import com.civicsphere.exception.ConflictException;
import com.civicsphere.exception.NotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
public class DepartmentService {

    private final DepartmentRepository departmentRepository;

    @Transactional(readOnly = true)
    public List<DepartmentResponse> getAllDepartments() {
        return departmentRepository.findAll().stream()
                .map(this::mapToResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public DepartmentResponse getDepartmentById(UUID id) {
        Department dept = departmentRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Department not found with ID: " + id));
        return mapToResponse(dept);
    }

    public DepartmentResponse createDepartment(CreateDepartmentRequest request) {
        if (departmentRepository.existsByCode(request.getCode())) {
            throw new ConflictException("Department code already exists: " + request.getCode());
        }

        Department dept = Department.builder()
                .name(request.getName())
                .code(request.getCode())
                .description(request.getDescription())
                .headName(request.getHeadName())
                .contactEmail(request.getContactEmail())
                .contactPhone(request.getContactPhone())
                .primaryCategory(request.getPrimaryCategory())
                .active(true)
                .build();

        return mapToResponse(departmentRepository.save(dept));
    }

    public DepartmentResponse updateDepartment(UUID id, CreateDepartmentRequest request) {
        Department dept = departmentRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Department not found with ID: " + id));

        if (!dept.getCode().equals(request.getCode()) && departmentRepository.existsByCode(request.getCode())) {
            throw new ConflictException("Department code already exists: " + request.getCode());
        }

        dept.setName(request.getName());
        dept.setCode(request.getCode());
        dept.setDescription(request.getDescription());
        dept.setHeadName(request.getHeadName());
        dept.setContactEmail(request.getContactEmail());
        dept.setContactPhone(request.getContactPhone());
        dept.setPrimaryCategory(request.getPrimaryCategory());

        return mapToResponse(departmentRepository.save(dept));
    }

    public void deleteDepartment(UUID id) {
        if (!departmentRepository.existsById(id)) {
            throw new NotFoundException("Department not found with ID: " + id);
        }
        departmentRepository.deleteById(id);
    }

    public DepartmentResponse mapToResponse(Department dept) {
        return DepartmentResponse.builder()
                .id(dept.getId())
                .name(dept.getName())
                .code(dept.getCode())
                .description(dept.getDescription())
                .headName(dept.getHeadName())
                .contactEmail(dept.getContactEmail())
                .contactPhone(dept.getContactPhone())
                .primaryCategory(dept.getPrimaryCategory())
                .active(dept.isActive())
                .build();
    }
}
