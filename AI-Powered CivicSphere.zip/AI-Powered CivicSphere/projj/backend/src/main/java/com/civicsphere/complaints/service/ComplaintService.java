package com.civicsphere.complaints.service;

import com.civicsphere.ai.entity.AiAnalysis;
import com.civicsphere.ai.dto.AiAnalysisResult;
import com.civicsphere.ai.repository.AiAnalysisRepository;
import com.civicsphere.ai.service.GeminiAiService;
import com.civicsphere.assignments.service.AssignmentService;
import com.civicsphere.common.enums.ComplaintStatus;
import com.civicsphere.common.enums.Priority;
import com.civicsphere.common.enums.Role;
import com.civicsphere.complaints.dto.ComplaintResponse;
import com.civicsphere.complaints.dto.CreateComplaintRequest;
import com.civicsphere.complaints.dto.RatingRequest;
import com.civicsphere.complaints.dto.UpdateStatusRequest;
import com.civicsphere.complaints.entity.Complaint;
import com.civicsphere.complaints.entity.ComplaintImage;
import com.civicsphere.complaints.entity.StatusHistory;
import com.civicsphere.complaints.repository.ComplaintRepository;
import com.civicsphere.common.dto.PageResponse;
import com.civicsphere.departments.entity.Department;
import com.civicsphere.departments.repository.DepartmentRepository;
import com.civicsphere.exception.ForbiddenException;
import com.civicsphere.exception.NotFoundException;
import com.civicsphere.notifications.service.NotificationService;
import com.civicsphere.users.entity.User;
import com.civicsphere.users.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class ComplaintService {

    private final ComplaintRepository complaintRepository;
    private final DepartmentRepository departmentRepository;
    private final UserRepository userRepository;
    private final AiAnalysisRepository aiAnalysisRepository;
    private final GeminiAiService geminiAiService;
    private final AssignmentService assignmentService;
    private final com.civicsphere.assignments.repository.AssignmentRepository assignmentRepository;
    private final NotificationService notificationService;
    private final FileStorageService fileStorageService;

    @Value("${app.sla.road-hours}")
    private int slaRoadHours;
    @Value("${app.sla.water-hours}")
    private int slaWaterHours;
    @Value("${app.sla.power-hours}")
    private int slaPowerHours;
    @Value("${app.sla.sanitation-hours}")
    private int slaSanitationHours;
    @Value("${app.sla.public-safety-hours}")
    private int slaPublicSafetyHours;
    @Value("${app.sla.default-hours}")
    private int slaDefaultHours;

    public ComplaintResponse createComplaint(CreateComplaintRequest request, List<MultipartFile> images) {
        User citizen = getCurrentUser();

        // 1. AI Analysis
        AiAnalysisResult aiResult = geminiAiService.analyzeComplaint(
                request.getTitle(), request.getDescription(), request.getAddress());

        // 2. Resolve department
        Department department = departmentRepository
                .findByPrimaryCategory(aiResult.getPredictedCategory())
                .orElse(null);

        // 3. Calculate SLA deadline
        LocalDateTime slaDeadline = calculateSlaDeadline(aiResult.getPredictedCategory());

        // 4. Build complaint
        Complaint complaint = Complaint.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .category(aiResult.getPredictedCategory())
                .priority(request.getPriority() != null ? request.getPriority() : aiResult.getPredictedPriority())
                .status(ComplaintStatus.SUBMITTED)
                .citizen(citizen)
                .department(department)
                .latitude(request.getLatitude())
                .longitude(request.getLongitude())
                .address(request.getAddress())
                .impactScore(aiResult.getImpactScore())
                .slaDeadline(slaDeadline)
                .build();

        complaint = complaintRepository.save(complaint);

        // 5. Store AI analysis
        AiAnalysis analysis = AiAnalysis.builder()
                .complaint(complaint)
                .predictedCategory(aiResult.getPredictedCategory())
                .predictedPriority(aiResult.getPredictedPriority())
                .confidence(aiResult.getConfidence())
                .sentiment(aiResult.getSentiment())
                .impactScore(aiResult.getImpactScore())
                .predictedDepartment(aiResult.getPredictedDepartment())
                .reasoning(aiResult.getReasoning())
                .build();
        aiAnalysisRepository.save(analysis);

        // 6. Add initial status history
        addStatusHistory(complaint, null, ComplaintStatus.SUBMITTED, "Complaint submitted by citizen", citizen);

        // 7. Upload images
        if (images != null && !images.isEmpty()) {
            List<ComplaintImage> savedImages = new ArrayList<>();
            for (MultipartFile image : images) {
                String url = fileStorageService.store(image, "complaints/" + complaint.getId());
                savedImages.add(ComplaintImage.builder()
                        .complaint(complaint)
                        .fileName(image.getOriginalFilename())
                        .url(url)
                        .fileSize(image.getSize())
                        .contentType(image.getContentType())
                        .build());
            }
            complaint.getImages().addAll(savedImages);
            complaintRepository.save(complaint);
        }

        // 8. Auto-assign to staff
        if (department != null) {
            assignmentService.autoAssign(complaint, department);
            updateStatus(complaint, ComplaintStatus.ASSIGNED, "Auto-assigned to department", null);
        }

        // 9. Notify citizen
        notificationService.notifyCitizenComplaintSubmitted(citizen, complaint);

        log.info("Complaint created: {} | Category: {} | Priority: {} | Dept: {}",
                complaint.getId(), aiResult.getPredictedCategory(), aiResult.getPredictedPriority(),
                aiResult.getPredictedDepartment());

        return mapToResponse(complaintRepository.findById(complaint.getId()).orElseThrow());
    }

    public ComplaintResponse updateStatus(UUID complaintId, UpdateStatusRequest request) {
        User actor = getCurrentUser();
        Complaint complaint = getComplaintOrThrow(complaintId);

        validateStatusTransition(complaint, request.getNewStatus(), actor);

        ComplaintStatus oldStatus = complaint.getStatus();
        complaint.setStatus(request.getNewStatus());

        if (request.getNewStatus() == ComplaintStatus.RESOLVED) {
            complaint.setResolvedAt(LocalDateTime.now());
        }

        addStatusHistory(complaint, oldStatus, request.getNewStatus(), request.getRemarks(), actor);
        complaint = complaintRepository.save(complaint);

        notificationService.notifyStatusChanged(complaint, oldStatus, request.getNewStatus());

        return mapToResponse(complaint);
    }

    public ComplaintResponse rateComplaint(UUID complaintId, RatingRequest request) {
        User citizen = getCurrentUser();
        Complaint complaint = getComplaintOrThrow(complaintId);

        if (!complaint.getCitizen().getId().equals(citizen.getId())) {
            throw new ForbiddenException("You can only rate your own complaints");
        }
        if (complaint.getStatus() != ComplaintStatus.RESOLVED && complaint.getStatus() != ComplaintStatus.CLOSED) {
            throw new ForbiddenException("Complaint must be resolved before rating");
        }

        complaint.setCitizenRating(request.getStars());
        complaint.setCitizenFeedback(request.getFeedback());
        complaint.setStatus(ComplaintStatus.CLOSED);
        complaintRepository.save(complaint);

        return mapToResponse(complaint);
    }

    @Transactional(readOnly = true)
    public PageResponse<ComplaintResponse> getMyCcomplaints(int page, int size) {
        User citizen = getCurrentUser();
        return PageResponse.from(
                complaintRepository.findByCitizen(citizen, PageRequest.of(page, size,
                        Sort.by("createdAt").descending()))
                        .map(this::mapToResponse)
        );
    }

    @Transactional(readOnly = true)
    public PageResponse<ComplaintResponse> getAssignedComplaints(int page, int size) {
        User staff = getCurrentUser();
        return PageResponse.from(
                assignmentRepository.findByStaffAndActive(staff, true, PageRequest.of(page, size,
                        Sort.by("assignedAt").descending()))
                        .map(a -> mapToResponse(a.getComplaint()))
        );
    }

    @Transactional(readOnly = true)
    public ComplaintResponse getComplaintById(UUID id) {
        return mapToResponse(getComplaintOrThrow(id));
    }

    @Transactional(readOnly = true)
    public PageResponse<ComplaintResponse> getAllComplaints(int page, int size) {
        return PageResponse.from(
                complaintRepository.findAll(PageRequest.of(page, size,
                        Sort.by("createdAt").descending()))
                        .map(this::mapToResponse)
        );
    }

    @Transactional(readOnly = true)
    public List<ComplaintResponse> getGeoComplaints() {
        return complaintRepository.findAllWithLocation().stream()
                .map(this::mapToResponse)
                .toList();
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────────

    private void updateStatus(Complaint complaint, ComplaintStatus newStatus, String remarks, User actor) {
        ComplaintStatus old = complaint.getStatus();
        complaint.setStatus(newStatus);
        addStatusHistory(complaint, old, newStatus, remarks, actor);
    }

    private void addStatusHistory(Complaint complaint, ComplaintStatus oldStatus,
                                   ComplaintStatus newStatus, String remarks, User updatedBy) {
        StatusHistory history = StatusHistory.builder()
                .complaint(complaint)
                .oldStatus(oldStatus)
                .newStatus(newStatus)
                .remarks(remarks)
                .updatedBy(updatedBy)
                .build();
        complaint.getStatusHistory().add(history);
    }

    private LocalDateTime calculateSlaDeadline(com.civicsphere.common.enums.ComplaintCategory category) {
        int hours = switch (category) {
            case ROAD -> slaRoadHours;
            case WATER -> slaWaterHours;
            case POWER -> slaPowerHours;
            case SANITATION -> slaSanitationHours;
            case PUBLIC_SAFETY -> slaPublicSafetyHours;
            default -> slaDefaultHours;
        };
        return LocalDateTime.now().plusHours(hours);
    }

    private void validateStatusTransition(Complaint complaint, ComplaintStatus newStatus, User actor) {
        Role role = actor.getRole();
        ComplaintStatus current = complaint.getStatus();

        boolean allowed = switch (role) {
            case STAFF -> newStatus == ComplaintStatus.IN_PROGRESS || newStatus == ComplaintStatus.RESOLVED;
            case SUPERVISOR -> true;
            case ADMIN, SUPER_ADMIN -> true;
            default -> false;
        };

        if (!allowed) {
            throw new ForbiddenException("Cannot transition to " + newStatus + " with role " + role);
        }
    }

    private Complaint getComplaintOrThrow(UUID id) {
        return complaintRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Complaint not found: " + id));
    }

    private User getCurrentUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new NotFoundException("User not found"));
    }

    public ComplaintResponse mapToResponse(Complaint c) {
        return ComplaintResponse.builder()
                .id(c.getId())
                .title(c.getTitle())
                .description(c.getDescription())
                .category(c.getCategory())
                .priority(c.getPriority())
                .status(c.getStatus())
                .citizen(ComplaintResponse.CitizenSummary.builder()
                        .id(c.getCitizen().getId())
                        .name(c.getCitizen().getName())
                        .email(c.getCitizen().getEmail())
                        .build())
                .department(c.getDepartment() != null ? ComplaintResponse.DepartmentSummary.builder()
                        .id(c.getDepartment().getId())
                        .name(c.getDepartment().getName())
                        .code(c.getDepartment().getCode())
                        .build() : null)
                .latitude(c.getLatitude())
                .longitude(c.getLongitude())
                .address(c.getAddress())
                .impactScore(c.getImpactScore())
                .slaDeadline(c.getSlaDeadline())
                .resolvedAt(c.getResolvedAt())
                .citizenRating(c.getCitizenRating())
                .citizenFeedback(c.getCitizenFeedback())
                .imageUrls(c.getImages().stream().map(ComplaintImage::getUrl).toList())
                .statusHistory(c.getStatusHistory().stream()
                        .map(h -> ComplaintResponse.StatusHistoryDto.builder()
                                .oldStatus(h.getOldStatus())
                                .newStatus(h.getNewStatus())
                                .remarks(h.getRemarks())
                                .updatedBy(h.getUpdatedBy() != null ? h.getUpdatedBy().getName() : "System")
                                .timestamp(h.getTimestamp())
                                .build())
                        .toList())
                .createdAt(c.getCreatedAt())
                .updatedAt(c.getUpdatedAt())
                .build();
    }
}
