package com.civicsphere.common.initializer;

import com.civicsphere.common.enums.ComplaintCategory;
import com.civicsphere.common.enums.Role;
import com.civicsphere.departments.entity.Department;
import com.civicsphere.departments.repository.DepartmentRepository;
import com.civicsphere.users.entity.User;
import com.civicsphere.users.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DatabaseInitializer implements CommandLineRunner {

    private final DepartmentRepository departmentRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        log.info("DatabaseInitializer: Starting checks for initial seeding...");

        // 1. Seed Departments if none exist
        if (departmentRepository.count() == 0) {
            log.info("DatabaseInitializer: Seeding default departments...");
            List<Department> defaultDepts = List.of(
                Department.builder().name("Roads & Infrastructure Dept").code("ROAD").description("Manages roads, potholes, and infrastructure").headName("Mr. Rajesh Kumar").contactEmail("roads@civicsphere.io").contactPhone("1234567890").primaryCategory(ComplaintCategory.ROAD).active(true).build(),
                Department.builder().name("Water Supply Board").code("WATER").description("Manages water supply, pipes, and leakages").headName("Ms. Priya Sharma").contactEmail("water@civicsphere.io").contactPhone("1234567891").primaryCategory(ComplaintCategory.WATER).active(true).build(),
                Department.builder().name("Electricity Board").code("POWER").description("Manages power supply and electrical issues").headName("Mr. Arun Menon").contactEmail("power@civicsphere.io").contactPhone("1234567892").primaryCategory(ComplaintCategory.POWER).active(true).build(),
                Department.builder().name("Sanitation & Waste Mgmt").code("SANIT").description("Manages garbage collection and drains").headName("Ms. Lakshmi Devi").contactEmail("sanit@civicsphere.io").contactPhone("1234567893").primaryCategory(ComplaintCategory.SANITATION).active(true).build(),
                Department.builder().name("Public Safety Dept").code("SAFETY").description("Manages public safety and law enforcement").headName("Mr. Vijay Singh").contactEmail("safety@civicsphere.io").contactPhone("1234567894").primaryCategory(ComplaintCategory.PUBLIC_SAFETY).active(true).build(),
                Department.builder().name("Parks & Recreation Dept").code("PARKS").description("Manages public parks and green spaces").headName("Ms. Ananya Nair").contactEmail("parks@civicsphere.io").contactPhone("1234567895").primaryCategory(ComplaintCategory.PARKS).active(true).build(),
                Department.builder().name("City Transport Authority").code("TRANS").description("Manages public transport and traffic").headName("Mr. Kiran Patel").contactEmail("trans@civicsphere.io").contactPhone("1234567896").primaryCategory(ComplaintCategory.TRANSPORTATION).active(true).build(),
                Department.builder().name("Health Department").code("HEALTH").description("Manages public health and sanitation").headName("Dr. Meera Iyer").contactEmail("health@civicsphere.io").contactPhone("1234567897").primaryCategory(ComplaintCategory.HEALTH).active(true).build(),
                Department.builder().name("General Administration").code("ADMIN").description("General civic administration").headName("Mr. Suresh Babu").contactEmail("admin@civicsphere.io").contactPhone("1234567898").primaryCategory(ComplaintCategory.OTHER).active(true).build()
            );
            departmentRepository.saveAll(defaultDepts);
            log.info("DatabaseInitializer: Default departments seeded successfully.");
        } else {
            log.info("DatabaseInitializer: Departments already present. Skipping department seeding.");
        }

        // 2. Seed Default Users if none exist
        if (userRepository.count() == 0) {
            log.info("DatabaseInitializer: Seeding default users...");

            Department roadDept = departmentRepository.findByCode("ROAD").orElse(null);
            Department waterDept = departmentRepository.findByCode("WATER").orElse(null);

            // Admin
            User admin = User.builder()
                .name("Admin User")
                .email("admin@civicsphere.io")
                .password(passwordEncoder.encode("admin123"))
                .role(Role.ADMIN)
                .active(true)
                .emailVerified(true)
                .phoneNumber("9999999999")
                .build();
            userRepository.save(admin);

            // Supervisor for Road Dept
            User supervisor = User.builder()
                .name("Road Supervisor")
                .email("supervisor@civicsphere.io")
                .password(passwordEncoder.encode("super123"))
                .role(Role.SUPERVISOR)
                .department(roadDept)
                .active(true)
                .emailVerified(true)
                .phoneNumber("8888888888")
                .build();
            userRepository.save(supervisor);

            // Staff for Road Dept
            User staffRoad = User.builder()
                .name("Road Staff")
                .email("staff@civicsphere.io")
                .password(passwordEncoder.encode("staff123"))
                .role(Role.STAFF)
                .department(roadDept)
                .active(true)
                .emailVerified(true)
                .phoneNumber("7777777777")
                .build();
            userRepository.save(staffRoad);

            // Staff for Water Dept
            User staffWater = User.builder()
                .name("Water Staff")
                .email("waterstaff@civicsphere.io")
                .password(passwordEncoder.encode("staff123"))
                .role(Role.STAFF)
                .department(waterDept)
                .active(true)
                .emailVerified(true)
                .phoneNumber("7777777778")
                .build();
            userRepository.save(staffWater);

            // Citizen
            User citizen = User.builder()
                .name("Citizen John")
                .email("citizen@civicsphere.io")
                .password(passwordEncoder.encode("citizen123"))
                .role(Role.CITIZEN)
                .active(true)
                .emailVerified(true)
                .phoneNumber("6666666666")
                .build();
            userRepository.save(citizen);

            log.info("DatabaseInitializer: Default users seeded successfully.");
        } else {
            log.info("DatabaseInitializer: Users already present. Skipping user seeding.");
        }
    }
}
