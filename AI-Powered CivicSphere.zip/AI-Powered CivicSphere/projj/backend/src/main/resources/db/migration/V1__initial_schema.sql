-- ============================================================
-- CivicSphere AI — Initial Database Schema
-- Flyway Migration V1
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── Departments ─────────────────────────────────────────────────────────────
CREATE TABLE departments (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name             VARCHAR(100) NOT NULL UNIQUE,
    code             VARCHAR(20)  NOT NULL UNIQUE,
    description      TEXT,
    head_name        VARCHAR(100),
    contact_email    VARCHAR(255),
    contact_phone    VARCHAR(20),
    primary_category VARCHAR(50),
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ─── Users ───────────────────────────────────────────────────────────────────
CREATE TABLE users (
    id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name              VARCHAR(100) NOT NULL,
    email             VARCHAR(255) NOT NULL UNIQUE,
    password          VARCHAR(255) NOT NULL,
    role              VARCHAR(20)  NOT NULL DEFAULT 'CITIZEN',
    department_id     UUID REFERENCES departments(id) ON DELETE SET NULL,
    phone_number      VARCHAR(20),
    profile_image_url VARCHAR(500),
    is_active         BOOLEAN NOT NULL DEFAULT TRUE,
    email_verified    BOOLEAN NOT NULL DEFAULT FALSE,
    created_at        TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- ─── Refresh Tokens ───────────────────────────────────────────────────────────
CREATE TABLE refresh_tokens (
    id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token      VARCHAR(512) NOT NULL UNIQUE,
    expires_at TIMESTAMP NOT NULL,
    is_revoked BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_refresh_tokens_user ON refresh_tokens(user_id);

-- ─── Complaints ───────────────────────────────────────────────────────────────
CREATE TABLE complaints (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title            VARCHAR(200) NOT NULL,
    description      TEXT NOT NULL,
    category         VARCHAR(30)  NOT NULL,
    priority         VARCHAR(20)  NOT NULL DEFAULT 'MEDIUM',
    status           VARCHAR(20)  NOT NULL DEFAULT 'SUBMITTED',
    citizen_id       UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    department_id    UUID REFERENCES departments(id) ON DELETE SET NULL,
    latitude         DOUBLE PRECISION,
    longitude        DOUBLE PRECISION,
    address          VARCHAR(500),
    impact_score     INTEGER,
    sla_deadline     TIMESTAMP,
    resolved_at      TIMESTAMP,
    rejection_reason TEXT,
    citizen_rating   INTEGER CHECK (citizen_rating BETWEEN 1 AND 5),
    citizen_feedback TEXT,
    created_at       TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_complaints_citizen ON complaints(citizen_id);
CREATE INDEX idx_complaints_status ON complaints(status);
CREATE INDEX idx_complaints_category ON complaints(category);
CREATE INDEX idx_complaints_department ON complaints(department_id);
CREATE INDEX idx_complaints_sla ON complaints(sla_deadline) WHERE status NOT IN ('RESOLVED','CLOSED','REJECTED','SLA_BREACHED');
CREATE INDEX idx_complaints_geo ON complaints(latitude, longitude) WHERE latitude IS NOT NULL;

-- ─── Complaint Images ─────────────────────────────────────────────────────────
CREATE TABLE complaint_images (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    complaint_id UUID NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
    file_name    VARCHAR(255) NOT NULL,
    s3_key       VARCHAR(500),
    url          VARCHAR(1000) NOT NULL,
    file_size    BIGINT,
    content_type VARCHAR(100),
    uploaded_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ─── Status History ───────────────────────────────────────────────────────────
CREATE TABLE status_history (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    complaint_id UUID NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
    old_status   VARCHAR(20),
    new_status   VARCHAR(20) NOT NULL,
    remarks      TEXT,
    updated_by   UUID REFERENCES users(id) ON DELETE SET NULL,
    timestamp    TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_status_history_complaint ON status_history(complaint_id);

-- ─── Assignments ──────────────────────────────────────────────────────────────
CREATE TABLE assignments (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    complaint_id UUID NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
    staff_id     UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    assigned_by  UUID REFERENCES users(id) ON DELETE SET NULL,
    is_active    BOOLEAN NOT NULL DEFAULT TRUE,
    assigned_at  TIMESTAMP NOT NULL DEFAULT NOW(),
    notes        TEXT
);

CREATE INDEX idx_assignments_complaint ON assignments(complaint_id);
CREATE INDEX idx_assignments_staff ON assignments(staff_id);

-- ─── AI Analyses ──────────────────────────────────────────────────────────────
CREATE TABLE ai_analyses (
    id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    complaint_id         UUID NOT NULL UNIQUE REFERENCES complaints(id) ON DELETE CASCADE,
    predicted_category   VARCHAR(30),
    predicted_priority   VARCHAR(20),
    confidence           DOUBLE PRECISION,
    sentiment            VARCHAR(20),
    impact_score         INTEGER,
    predicted_department VARCHAR(100),
    duplicate_of_id      UUID,
    similarity_score     DOUBLE PRECISION,
    reasoning            TEXT,
    analyzed_at          TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ─── Notifications ────────────────────────────────────────────────────────────
CREATE TABLE notifications (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title          VARCHAR(200) NOT NULL,
    message        TEXT NOT NULL,
    type           VARCHAR(30) NOT NULL DEFAULT 'SYSTEM',
    read_status    BOOLEAN NOT NULL DEFAULT FALSE,
    reference_id   UUID,
    reference_type VARCHAR(50),
    created_at     TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_notifications_unread ON notifications(user_id, read_status) WHERE read_status = FALSE;

-- ─── Audit Logs ───────────────────────────────────────────────────────────────
CREATE TABLE audit_logs (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_type  VARCHAR(50) NOT NULL,
    entity_id    VARCHAR(100),
    action       VARCHAR(100) NOT NULL,
    performed_by VARCHAR(255),
    details      TEXT,
    ip_address   VARCHAR(50),
    timestamp    TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);

-- ─── Seed Default Departments ─────────────────────────────────────────────────
INSERT INTO departments (name, code, description, head_name, contact_email, primary_category) VALUES
('Roads & Infrastructure Dept', 'ROAD', 'Manages roads, potholes, and infrastructure', 'Mr. Rajesh Kumar', 'roads@civicsphere.io', 'ROAD'),
('Water Supply Board',          'WATER', 'Manages water supply, pipes, and leakages',  'Ms. Priya Sharma', 'water@civicsphere.io', 'WATER'),
('Electricity Board',           'POWER', 'Manages power supply and electrical issues',  'Mr. Arun Menon',  'power@civicsphere.io', 'POWER'),
('Sanitation & Waste Mgmt',     'SANIT', 'Manages garbage collection and drains',       'Ms. Lakshmi Devi','sanit@civicsphere.io', 'SANITATION'),
('Public Safety Dept',          'SAFETY','Manages public safety and law enforcement',   'Mr. Vijay Singh', 'safety@civicsphere.io','PUBLIC_SAFETY'),
('Parks & Recreation Dept',     'PARKS', 'Manages public parks and green spaces',       'Ms. Ananya Nair', 'parks@civicsphere.io', 'PARKS'),
('City Transport Authority',    'TRANS', 'Manages public transport and traffic',        'Mr. Kiran Patel', 'trans@civicsphere.io', 'TRANSPORTATION'),
('Health Department',           'HEALTH','Manages public health and sanitation',        'Dr. Meera Iyer',  'health@civicsphere.io','HEALTH'),
('General Administration',      'ADMIN', 'General civic administration',               'Mr. Suresh Babu', 'admin@civicsphere.io', 'OTHER');
